# Landing-Page
The first project of front-end professional track

## Table of Contents

  * [Info.](#Info.)

## 

The starter project had some HTML and CSS styling to display a static version of the Landing Page project. The project has been converted from a static project to an interactive one by modifying the HTML and CSS files, but primarily the JavaScript file.

Both `./js/app.js` and `css/style.css` were integrated to the `index.html` file to start building out the app's functionality

Comments have been provided to the `js/app.js` file.
